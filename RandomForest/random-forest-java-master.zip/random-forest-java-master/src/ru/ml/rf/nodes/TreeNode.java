package ru.ml.rf.nodes;

public abstract class TreeNode {

    protected int depth;

    public TreeNode() {
        depth = 0;
    }
}
