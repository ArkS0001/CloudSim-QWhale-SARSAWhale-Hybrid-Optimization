package datacenter;

/**
 * @author : LA4AM12
 * @create : 2023-03-15 09:43:57
 * @description :
 */
public interface Constants {
	/**
	 * Low performance mips
	 */
	public static final int L_MIPS = 1000;

	/**
	 * Medium performance mips
	 */
	public static final int M_MIPS = 2000;

	/**
	 * High performance mips
	 */
	public static final int H_MIPS = 4000;

	/**
	 * Low performance price ($ per sec)
	 */
	public static final double L_PRICE = 0.3;

	/**
	 * Medium performance price ($ per sec)
	 */
	public static final double M_PRICE = 0.5;

	/**
	 * High performance price ($ per sec)
	 */
	public static final double H_PRICE = 0.9;

	/**
	 * Low performance vms count
	 */
	public static final int L_VM_N = 1;

	/**
	 * Medium performance vms count
	 */
	public static final int M_VM_N = 1;

	/**
	 * High performance vms count
	 */
	public static final int H_VM_N = 1;

	/**
	 * RAM of each VM (MB)
	 */
	public static final int RAM = 2048;

	/**
	 * VM storage capacity
	 */
	public static final long STORAGE = 100000;

	/**
	 * VM image size
	 */
	public static final long IMAGE_SIZE = 10000;

	/**
	 * VM bandwidth
	 */
	public static final int BW = 1024;
}


//public class Constants {
//    // Cloudlet parameters
//    public static final int CLOUDLET_LENGTH_MIN = 10000;
//    public static final int CLOUDLET_LENGTH_MAX = 50000;
//    public static final int CLOUDLET_FILE_SIZE_MIN = 10;
//    public static final int CLOUDLET_FILE_SIZE_MAX = 200;
//    public static final int CLOUDLET_OUTPUT_SIZE_MIN = 10;
//    public static final int CLOUDLET_OUTPUT_SIZE_MAX = 200;
//
//    // VM parameters
//    public static final int VM_MIPS_LOW = 1000;
//    public static final int VM_MIPS_MEDIUM = 2000;
//    public static final int VM_MIPS_HIGH = 3000;
//    public static final int VM_RAM = 2048; // in MB
//    public static final int VM_BW = 1000; // in Mbps
//    public static final int VM_PES_NUMBER = 1;
//
//    // Datacenter parameters
//    public static final int DATA_CENTER_RAM_LOW = 8192; // in MB
//    public static final int DATA_CENTER_RAM_MEDIUM = 16384; // in MB
//    public static final int DATA_CENTER_RAM_HIGH = 32768; // in MB
//    public static final int DATA_CENTER_BW = 10000; // in Mbps
//    public static final int DATA_CENTER_STORAGE = 1000000; // in MB
//    public static final double DATA_CENTER_COST_PER_SEC_LOW = 3.0; // in $/sec
//    public static final double DATA_CENTER_COST_PER_SEC_MEDIUM = 5.0; // in $/sec
//    public static final double DATA_CENTER_COST_PER_SEC_HIGH = 7.0; // in $/sec
//
//    // Other constants
//    public static final int NUM_USER = 1;
//    public static final int NUM_QLEARNING_ITERATIONS = 1000;
//    public static final int TOTAL_VM_COUNT = 15; // Total number of VMs in the system
//}
