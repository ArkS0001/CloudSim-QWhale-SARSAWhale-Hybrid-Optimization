package datacenter;

/**
 * @author : LA4AM12
 * @create : 2023-02-10 11:20:01
 * @description : optimization function
 */
public interface OptFunction {
	double calc(int[] params);
}